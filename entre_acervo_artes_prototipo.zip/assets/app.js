const state={arts:[],artists:[]};

async function loadData(){
  try{
    const r=await fetch("data/arts.json");
    state.arts=await r.json();
    const a=await fetch("data/artists.json");
    state.artists=await a.json();
    renderArts(state.arts);
    renderArtists(state.artists);
  }catch(e){console.error("Abra o projeto por um servidor local (ex.: Live Server).",e)}
}
function renderArts(items){
  document.querySelector("#art-grid").innerHTML=items.map((x,i)=>`
    <article class="work" data-category="${x.category}">
      <div class="visual"><img src="${x.image}" alt="${x.title}"></div>
      <div class="work-info"><div><div class="work-title">${x.title}</div><small>${x.artist} · ${x.year}</small></div><div class="work-meta">${x.technique}<br>${x.theme}</div></div>
    </article>`).join("");
}
function renderArtists(items){
 document.querySelector("#artist-list").innerHTML=items.map((x,i)=>`
  <a class="artist" href="#">
   <span class="artist-num">${String(i+1).padStart(2,"0")}</span>
   <span class="artist-name">${x.name}</span>
   <span class="artist-course">${x.course}</span>
   <span class="artist-link">Ver portfólio ↗</span>
  </a>`).join("");
}
document.addEventListener("click",e=>{
 const f=e.target.closest(".filter");
 if(f){
  document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));f.classList.add("active");
  const v=f.dataset.filter;
  renderArts(v==="all"?state.arts:state.arts.filter(x=>x.category===v));
 }
});
document.querySelector("#surprise").addEventListener("click",()=>{
 if(!state.arts.length)return;
 const x=state.arts[Math.floor(Math.random()*state.arts.length)];
 const box=document.querySelector("#surprise-result");
 box.innerHTML=`<img src="${x.image}" alt="${x.title}"><div class="work-info"><div><div class="work-title">${x.title}</div><small>${x.artist}</small></div><div class="work-meta">${x.technique}</div></div>`;
 box.classList.remove("show");void box.offsetWidth;box.classList.add("show");
});
loadData();
